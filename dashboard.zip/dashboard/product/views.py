from django.shortcuts import render,get_object_or_404,HttpResponse
from .models  import Product
import pandas as pd

# Create your views here.
df_vente = pd.read_csv('/home/khalil/Videos/eco/dashboard_django/dashboard/chart/stock.csv', encoding='UTF-8')
#print(df_vente.columns)
#for i in range(2):
      #name=df_vente['Désignation'][i]
      #category=df_vente['Catégorie'][i]
      #quantity=df_vente['Quantité'][i]
      #p1=Product.objects.create(name=str(name),qantity=float(quantity.replace(',','')),category=category)
def add_product(request):
    #our_data={'product_name':[],'product_sku':[],'product_qantity':[],'product_price':[]}
    our_data=request.GET
    if len(our_data)>1:

        name=our_data['product_name']
        sku=our_data['product_sku']
        qantity=our_data['product_qantity']
        price=our_data['product_price']
        brand=our_data['product_brand']
        unit=our_data['product_unit']
        category=our_data['product_category']
        p1=Product.objects.create(name=name,price=price,sku=sku,qantity=qantity,category=category,brand=brand,unit=unit)
   
        
    return render(request,'product/addproduct.html')


def list_product(request):
    context={'all_products':Product.objects.all}
    print("55555",request.GET)
    return render(request,'product/productlist.html',context=context)

def product_detail(request,id):
        context=get_object_or_404(Product,pk=id)
        return render(request,'product/product-details.html',{'product':context})
def edit_product(request,id):
        context=get_object_or_404(Product,pk=id)
        our_data=request.GET
        if len(our_data)>1:

            name=our_data['product_name']
            sku=our_data['product_sku']
            qantity=our_data['product_qantity']
            price=our_data['product_price']
            brand=our_data['product_brand']
            unit=our_data['product_unit']
            category=our_data['product_category']
            p1=Product.objects.filter(id=id).update(id=id,name=name,price=price,sku=sku,qantity=qantity,category=category,brand=brand,unit=unit)   
        return render(request,'product/editproduct.html',{'product':context})
def delet_product(request,id):
            if len(request.GET)==0:
                print('yes')
            
            elif 'delet'  in str(request.GET.get):
                print("delet",request.GET)
                p_delet=Product.objects.filter(id=id).delete()
                context={'all_products':Product.objects.all}
                return render(request,'product/productlist.html',context=context)
            elif 'Cancel' in str(request.GET.get):
                print("cancel",request.GET)
                context={'all_products':Product.objects.all}
                return render(request,'product/productlist.html',context=context)
                
            
            return render(request,"product/deletproduct.html")


     
