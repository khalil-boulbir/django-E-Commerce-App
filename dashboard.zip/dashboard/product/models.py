from django.db import models
from django.db.models import Model
from django.urls import reverse
# Create your models here.




class Product(models.Model):
    name=models.CharField(max_length=500)
    price=models.FloatField(max_length=500,null=True)
    qantity=models.FloatField(max_length=500,null=True)
    unit = models.CharField(max_length = 500,null=True)
    sku = models.CharField(max_length = 500,null=True)
    brand = models.CharField(max_length = 500,null=True)
    category = models.CharField(max_length = 500,null=True)
    description = models.CharField(max_length = 500,null=True)
    slug = models.SlugField(max_length = 500,null=True)
    
    def get_absolute_url(self):
        return reverse("product_details", kwargs={"slug": self.slug})
    
    def get_categry(self,categories):
        if categories== self.category:
            return

    
    
    
    

    def __str__(self):
        return self.name

