from django.shortcuts import render,get_object_or_404,HttpResponse
from product import   models as product_models
from people import models as people_models
from .models import Purchase
import pandas as pd
# Create your views here.
list_of_product=[]
suppliers={}
name_of_suppliers=people_models.Supplier.objects.values()
for i in name_of_suppliers:
    suppliers[f"{i['name']}"]=[]
def merge_two_dicts(x, y):
    z = x.copy()   # start with keys and values of x
    z.update(y)    # modifies z with keys and values of y
    return z

def purchase_list(request):
    context={'purchases':Purchase.objects.all()}
    return render(request,'purchase/purchaselist.html',context=context)



def add_purchase(request):
    global list_of_product
    global suppliers
    our_data=request.GET
    if len(our_data)>0:

        if 'Submit' in str(our_data):
            first_total=0
            for i in list_of_product:
                first_total=first_total+i.total()
            discount=(float(request.GET["discount"])*0.01*first_total)
            shipping=float(request.GET["shipping"])
            grand_total=first_total+shipping-discount
            purchase=Purchase.objects.create(supplier=list_of_product[0].supplier,discount=discount,shipping=shipping,Status=our_data['status'],reference=our_data["reference"],grand_total=grand_total)
            return render(request,'purchase/addpurchase.html',{'first_purchase':Purchase.objects.all()[len(Purchase.objects.all())-1],'purchases':list_of_product,'all_proudcts':product_models.Product.objects.all,'all_suppliers':people_models.Supplier.objects.all})

        else:
            supplier=our_data["supplier"]
            product=our_data["name_of_prodcut"]
            date=our_data["date"]
            price=our_data["price_of_product"]
            quantity=our_data["quantity_of_product"]
            product_models.Product.objects.filter(name=product).update(price=price,qantity=quantity)
            dict=SaveData(product,date,price,quantity,supplier)
            list_of_product.append(dict)
            return render(request,'purchase/addpurchase.html',{'purchases':list_of_product,'all_proudcts':product_models.Product.objects.all,'all_suppliers':people_models.Supplier.objects.all})
    else:
        list_of_product=[]
        context={'all_proudcts':product_models.Product.objects.all,'all_suppliers':people_models.Supplier.objects.all}

        return render(request,'purchase/addpurchase.html',context=context)
def delet_purchase(request,id):
       

        if len(request.GET)==0:
            print('yes')
        
        elif 'delet'  in str(request.GET.get):
            print("delet",request.GET)
            p_delet=Purchase.objects.filter(id=id).delete()
            context={'purchases':Purchase.objects.all()}
            return render(request,'purchase/purchaselist.html',context=context)
        elif 'Cancel' in str(request.GET.get):
            print("cancel",request.GET)
            context={'purchases':Purchase.objects.all()}
            return render(request,'purchase/purchaselist.html',context=context)
            
        
        return render(request,"purchase/deletpurchase.html")

class SaveData():
    
    
    def __init__(self,product,date,price,quantity,supplier):
        self.product=product
        self.date=date
        self.price=price
        self.quantity=quantity
        self.supplier=supplier
    def total(self):
        return float(self.price)* float(self.quantity)  
    

    