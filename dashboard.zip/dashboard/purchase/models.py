from django.db import models
from product import   models as product_models
from people import models as people_models
# Create your models here.


class Purchase(models.Model):
    reference = models.CharField(max_length=100,null=True)
    supplier = models.CharField(null=True,max_length=250000)
    date = models.CharField(max_length=11,null=True)
    shipping=models.IntegerField(null=True)
    discount=models.CharField(max_length=5,null=True)
    grand_total=models.CharField(max_length=50000000000000000,null=True)

    Status=models.CharField(max_length=20,null=True)

    def __str__(self) :
        return self.reference