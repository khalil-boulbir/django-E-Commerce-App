from django.contrib import admin
from django.urls import path
from django.urls import include
from .import views
urlpatterns = [
    path('purchase_list',views.purchase_list,name='purchase_list'),
    path('add_purchase',views.add_purchase,name='add_new_purchase'),

    path('delet_purchase/<int:id>',views.delet_purchase,name='delet_purchase'),





]