import plotly.graph_objs as go
import plotly.express as px

from django.shortcuts import render
import plotly.offline as opy
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt


df_vente = pd.read_csv('/home/khalil/Videos/eco/dashboard_django/dashboard/chart/stock.csv', encoding='UTF-8')
q_entere=[]
q_sortie=[]
quantity=[]
our_data=[]
for i in df_vente['Qte Entrée']:
    q_entere.append(float(str(i).replace(',','')))
for i in df_vente['Qte Sortie']:
    q_sortie.append(float(str(i).replace(',','')))
for i in range(len(q_sortie)):
    if 'nan' in str(q_sortie[i]):
        quantity.append(q_entere[i])
    elif 'nan' in str(q_entere[i]):
        quantity.append(q_sortie[i])
    else:
        quantity.append(0)
q_entre=[]
for i in df_vente['Qte Entrée']:
    if 'nan' in str(i):
        q_entre.append(0)
    else:
        q_entre.append(float(str(i).replace(',','')))
df_vente['Qte Entrée']=q_entre
q_Sortie=[]
for i in df_vente['Qte Sortie']:
    if 'nan' in str(i):
        q_Sortie.append(0)
    else:
        q_Sortie.append(float(str(i).replace(',','')))
df_vente['Qte Sortie']=q_Sortie
        
df_vente['Quantité']=quantity
#convert data to reel type and fill na value with mean 
df_vente['Quantité']=pd.to_numeric(df_vente['Quantité'], errors="coerce")
#df_vente['PU']=pd.to_numeric(df_vente['PU'], errors="coerce")
df_vente['Date']=pd.to_datetime(df_vente['Date'])
df_vente['year']=df_vente['Date'].dt.year
df_vente['month']=df_vente['Date'].dt.month
df_vente['day']=df_vente['Date'].dt.day
vmcum=[]
prcum=[]
order=[]
classe=[]
conteur=0
ind=[]
s=0
p=0
#methode abc 
dat=df_vente.groupby('Catégorie')['Quantité'].sum().reset_index(name='Total Quantity')#read data
dat["vm"]=dat['Total Quantity']#the attribute
vm=dat["vm"].to_numpy()
x=np.sort(vm)
x=x[::-1]
dat=dat.sort_values(by=["vm"],ascending=False)
for i in x:
    s=s+i
    vmcum.append(s)
total=np.sum(vm)
for i in range(len(vmcum)):
    prcum.append((vmcum[i]/total)*100)
dat["vm"]=vm
dat["vm ordonne"]=x
dat["vm cummule"]=vmcum
dat["% cummule"]=prcum
for i in range(len(dat)):
    conteur=conteur+(100/len(dat))
    if(conteur<=20):
        classe.append("A")
    elif(conteur>20 and conteur<80):
        classe.append("B")
    else:
        classe.append("C")
    
dat["classement ABC"]=classe   

year=2022

#plot

def top_product_in_year(request,data=df_vente):
    if len(request.GET)>0:
        if "'Submit':" in  str(request.GET):
              year=float(request.GET['year'])
        else:
            year=2021
    else:
        year=2021
    data=data[data['year']==year]
    df=data.groupby('Catégorie')['Quantité'].sum().reset_index(name='Total Quantity')
    name=df[0:1]['Catégorie'][0]
    data=data[data['Catégorie']==name]

    df=data.groupby('month')['Quantité'].sum().reset_index(name='Total Quantity')

    df['month']=['January', 'February', 'March', 'April', 'May', 'June', 'July','August', 'September', 'October', 'November', 'December']

    fig = px.bar(df, x="month", y="Total Quantity",title=f'Product Trends by Month in {year}',color='month')


    div = opy.plot(fig, auto_open=False, output_type='div')
    if len(request.GET)>0:
        if "'year_sales':" in str(request.GET):
            year_sales=float(request.GET['year_sales'])
            month_sales=float(request.GET['month_sales'])
        else:
            year_sales=2021
            month_sales=6
    else:
        year_sales=2021
        month_sales=6
    df_sales=df_vente[df_vente['year']==year_sales]
    df_sales=df_sales[df_sales['month']==month_sales]
    df_sales=df_sales.groupby('Catégorie')['Quantité'].sum()

    fig=px.bar(df_sales,x=df_sales.values,y=df_sales.index,color=df_sales.values)
    div_sales = opy.plot(fig, auto_open=False, output_type='div')
    if len(request.GET)>0:
        if "'year_stock':" in str(request.GET):
            year_stock=float(request.GET['year_stock'])
            month_stock=float(request.GET['month_stock'])
        year_stock=2021
        month_stock=6
    else:
        year_stock=2021
        month_stock=6
    
    df_stock=df_vente[df_vente['year']==year_stock]
    df_stock=df_stock[df_stock['month']==month_stock]
    df1=df_stock.groupby('day')['Qte Entrée'].sum().reset_index(name='Total Quantity')
    df2=df_stock.groupby('day')['Qte Sortie'].sum().reset_index(name='Total Quantity')
    layout = go.Layout(title='Bar Chart', xaxis=dict(title='X-axis'), yaxis=dict(title='Y-axis'))
    trace1 = go.Bar(x=list(df1['day']), y=list(df1['Total Quantity']), name='Qte Entrée', marker=dict(color='blue'))
    trace2 = go.Bar(x=list(df2['day']), y=list(df2['Total Quantity']), name='Qte Sortie', marker=dict(color='red'))

    data_plot= [trace1, trace2]
    fig = go.Figure(data=data_plot, layout=layout)
    fig.update_layout(
    width=750,
    height=700,)
    div_stock = opy.plot(fig, auto_open=False, output_type='div')
    if len(request.GET)>0:
        if "'Submit_every_product':" in  str(request.GET):
              year_every_product=float(request.GET['year_every_product'])
              name_every_product=request.GET['Product_categorie']
        else:
            year_every_product=2021
            name_every_product='Miel'
    else:
        year_every_product=2021
        name_every_product='Miel'
    data_every_sale=df_vente[df_vente['year']==year_every_product]
    data_every_sale=data_every_sale[data_every_sale['Catégorie']==name_every_product]
    df_every_sales=data_every_sale.groupby('month')['Quantité'].sum().reset_index(name='Total Quantity')
    y_month=df_every_sales['Total Quantity']
    df_every_sales['month']=['January', 'February', 'March', 'April', 'May', 'June', 'July','August', 'September', 'October', 'November', 'December']
    x_month=df_every_sales['month']
    fig = px.line(df_every_sales, x="month", y="Total Quantity",title=f'Product Trends by Month in {year}')
    fig.add_bar(x=[i for i in x_month], y=[i for i in y_month],name=name_every_product)

    fig.update_layout(
    width=750,
    height=700,)
    div_every_product = opy.plot(fig, auto_open=False, output_type='div')
    if len(request.GET)>0:
        if "'depot':" in str(request.GET):
            year_depot=float(request.GET['year_depot'])
            month_depot=float(request.GET['month_depot'])
        else:
            year_depot=2021
            month_depot=6
    else:
        year_depot=2021
        month_depot=6
    df_depot=df_vente[df_vente['year']==year_depot]
    df_depot=df_depot[df_depot['month']==month_depot]
    df_depot=df_depot.groupby('Dépôt')['Quantité'].sum().reset_index(name='Quantité')
    names=[i.replace('Dépôt' ,'') for i in df_depot['Dépôt']]
    
    df_depot['Entropôt']=names
    print(df_depot)
    fig = px.pie(df_depot,values='Quantité', names='Entropôt' ,title=' Total Quantity of Company Entropôt',color_discrete_sequence=px.colors.sequential.RdBu,hole=.4)
    fig.update_layout(
    width=600,
    height=500,)
    div_depot = opy.plot(fig, auto_open=False, output_type='div')
    #methode abc 
    fig=px.bar(dat,x='Catégorie',y='% cummule',color='classement ABC')
    fig.update_layout(
    width=750,
    height=700,)
    div_abc = opy.plot(fig, auto_open=False, output_type='div')

    return render(request, 'chart/chart-apex.html', {'sales_every_day_of_month': 
                    div_sales,'plot_div':div,'stocks':div_stock,'every_product':div_every_product,'depot':div_depot,'methode_abc':div_abc})

    



