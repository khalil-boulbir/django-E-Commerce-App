from django.shortcuts import render,get_object_or_404,HttpResponse
from .models import Costumer,Supplier
# Create your views here.


def add_customer(request):

    our_data=request.GET
    if len(our_data)>1:
        name=our_data["name"]
        phone=our_data["phone"]
        email=our_data["email"]
        city=our_data["city"]
        adress=our_data["adress"]
        description=our_data["description"]
        customer=Costumer.objects.create(name=name,phone=phone,email=email,city=city,adress=adress,description=description)
    return render(request,'people/addcustomer.html')
def customer_list(request):
        context={'customers':Costumer.objects.all}

        return render(request,'people/customerlist.html',context=context)

def edit_customer(request,id):
        context=get_object_or_404(Costumer,pk=id)
        our_data=request.GET
        if len(our_data)>1:

            name=our_data["name"]
            phone=our_data["phone"]
            email=our_data["email"]
            city=our_data["city"]
            adress=our_data["adress"]
            description=our_data["description"]
            c=Costumer.objects.filter(id=id).update(id=id,name=name,phone=phone,email=email,adress=adress,city=city,description=description)   
        return render(request,'people/editcustomer.html',{'customer':context})
def deletecustomer(request,id):
            if len(request.GET)==0:
                print('yes')
            
            elif 'delet'  in str(request.GET.get):
                print("delet",request.GET)
                p_delet=Costumer.objects.filter(id=id).delete()
                context={'customers':Costumer.objects.all}
                return render(request,'people/customerlist.html',context=context)
            elif 'Cancel' in str(request.GET.get):
                print("cancel",request.GET)
                context={'customers':Costumer.objects.all}
                return render(request,'people/customerlist.html',context=context)
                
            
            return render(request,"people/deletcustomer.html")
     

def add_supplier(request):

    our_data=request.GET
    if len(our_data)>1:
        name=our_data["name"]
        phone=our_data["phone"]
        email=our_data["email"]
        country=our_data["country"]
        city=our_data["city"]
        adress=our_data["adress"]
        description=our_data["description"]
        supplier=Supplier.objects.create(name=name,phone=phone,email=email,city=city,adress=adress,description=description,country=country)
    return render(request,'people/addsupplier.html')
def supplier_list(request):
        context={'suppliers':Supplier.objects.all}

        return render(request,'people/supplierlist.html',context=context)

def edit_supplier(request,id):
        context=get_object_or_404(Supplier,pk=id)
        our_data=request.GET
        if len(our_data)>1:

            name=our_data["name"]
            phone=our_data["phone"]
            email=our_data["email"]
            country=our_data["country"]
            city=our_data["city"]
            adress=our_data["adress"]
            description=our_data["description"]
            s=Supplier.objects.filter(id=id).update(id=id,name=name,phone=phone,email=email,adress=adress,city=city,description=description,country=country)   
        return render(request,'people/editsupplier.html',{'supplier':context})
     
def deletesupplier(request,id):
            if len(request.GET)==0:
                print('yes')
            
            elif 'delet'  in str(request.GET.get):
                print("delet",request.GET)
                p_delet=Supplier.objects.filter(id=id).delete()
                context={'suppliers':Supplier.objects.all}
                return render(request,'people/supplierlist.html',context=context)
            elif 'Cancel' in str(request.GET.get):
                print("cancel",request.GET)
                context={'suppliers':Supplier.objects.all}
                return render(request,'people/supplierlist.html',context=context)
                
            
            return render(request,"people/deletcustomer.html")


     


     
