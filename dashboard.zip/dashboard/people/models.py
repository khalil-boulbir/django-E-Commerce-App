from django.db import models

# Create your models here.


class Costumer(models.Model):
    name = models.CharField(max_length = 150)
    
    email=models.EmailField(max_length=254,null=True)
    phone=models.IntegerField()
    city = models.CharField(max_length=30,null=True)
    adress = models.CharField(max_length=30,null=True)
    description=models.CharField(max_length=200,null=True)

    def _str__(self):
        return self.name
    
class Supplier(models.Model):
    name = models.CharField(max_length = 150,null=True)
    
    email=models.EmailField(max_length=254,null=True)
    phone=phone=models.IntegerField()
    country = models.CharField(max_length=30,null=True)
    city = models.CharField(max_length=30,null=True)
    adress = models.CharField(max_length=30,null=True)
    description=models.CharField(max_length=200,null=True)

    def _str__(self):
        return self.name