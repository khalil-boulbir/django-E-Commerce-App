from django.shortcuts import render
from django.http import HttpResponse
import os
import pandas as pd 
# Create your views here.


context={'sales_value_day':'78855'}
def index(request):
    return render(request,'index.html',context=context)
def stock(request):
    return render('widget.html',request)