from django.contrib import admin
from django.urls import path
from django.urls import include
from .import views
urlpatterns = [
    path('sales_list/',views.list_sales,name='sales_list'),
    path('new_sales/',views.new_slaes,name='new_sales'),
    path('add_sales/',views.add_sales,name='add_sales'),

    path('<int:id>',views.sales_detail,name='sales_details'),
    path('edit_sales/<int:id>',views.edit_sales,name='edit_sales'),



]