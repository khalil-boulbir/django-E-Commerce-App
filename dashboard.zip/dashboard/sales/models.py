from django.db import models

# Create your models here.

class Sales(models.Model):
    referance = models.CharField(max_length = 150)
    date=models.CharField(max_length=50)
    total_price=models.IntegerField()
    