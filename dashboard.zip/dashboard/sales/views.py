from django.shortcuts import render,get_object_or_404,HttpResponse
from product import models
# Create your views here.

def merge_two_dicts(x, y):
    z = x.copy()   # start with keys and values of x
    z.update(y)    # modifies z with keys and values of y
    return z
first_quantity={'first_quantity':0}
list_of_product=[]
def new_slaes(request):
    #our_data={'sales_name':[],'sales_sku':[],'sales_qantity':[],'sales_price':[]}
    if len(request.GET)>0:
            if 'Categories' in str(request.GET):
                global list_of_product
                context={'products':models.Product.objects.filter(category= request.GET ['Categories']).values(),'products_select':list_of_product,}

                return render(request,'sales/pos.html',context=context)
            elif 'select' in request.GET :
                
                name=request.GET['select']
                k=0
            
                for i in models.Product.objects.filter(name=name).values():
                    if str(i['name']) in str(list_of_product):
                        pass
                    else:
                            
                            new_dict=merge_two_dicts(first_quantity,i)
                            list_of_product.append(new_dict)
                            k=k+1
                    
                print("list_of_product",list_of_product)
                context={'products_select':list_of_product,'products':models.Product.objects.filter(category=list_of_product[k-1]['category']).values(),
                         'total_items':str(len(list_of_product)),
                         
                         
                         }
            


                return render(request,'sales/pos.html',context=context)
            if 'total_price' in request.GET:
                list_of_product=[]
           
            
        
    return render(request,'sales/pos.html')

def add_sales(request):
    context={'all_products':models.Product.objects.all()}
    return render(request,'sales/add-sales.html')

def list_sales(request):
    return render(request,'sales/saleslist.html')

def sales_detail(request,id):
        return render(request,'sales/sales-details.html')
def edit_sales(request,id):
        return render(request,'sales/edit-sales.html')

